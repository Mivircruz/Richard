#include "client/main.h"

#include <iostream>
#include <vector>

#include "client/application.h"
#include "core/engine.h"
#include "graphics/mesh.h"
#include "graphics/rendermesh.h"
#include "graphics/shader.h"

using namespace std;

class ClientApp : public Richard::Application {
public:

    ClientApp() {
        Engine::GetInstance()->GetWindow()->SetSize(800, 600);
    }

    void Initialize() override {
        Engine::GetInstance()->GetRenderer()->SetClearColor(2.0f / 255.0f, 97.0f / 255.0f, 53.0f / 255.0f, 1.0f);

        // Define the square
        // We will define two triangles that togehter make the square
        float vertices[] = {
            0.5f,   0.5f,  0.f,
            0.5f,  -0.5f,  0.f,
            -0.5f, -0.5f,  0.f,
            -0.5f,  0.5f,  0.f
        };
        uint32_t indices[]{
            0, 3, 1, // first triangle
            1, 3, 2  // second triangle
        };
        mMesh = make_shared<Richard::Graphics::Mesh>(&vertices[0], 4, 3, &indices[0], 6);

        mShader = make_shared<Richard::Graphics::Shader>("resources/shaders/square_vs.txt", "resources/shaders/square_fs.txt");

    }

    void Shutdown() override {
    }

    void Update() override {
    }

    void Render() override {
        auto renderCommand = make_unique<Richard::Graphics::RenderMesh>(mMesh, mShader);
        Engine::GetInstance()->GetRenderer()->Submit(move(renderCommand));
        Engine::GetInstance()->GetRenderer()->Execute();
    }

private:
    shared_ptr<Richard::Graphics::Mesh> mMesh;
    shared_ptr<Richard::Graphics::Shader> mShader;
};

Richard::Application* CreateApplication() {
    return new ClientApp();
}